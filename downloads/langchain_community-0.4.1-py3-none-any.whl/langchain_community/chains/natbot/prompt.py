from langchain_classic.chains.natbot.prompt import PROMPT

__all__ = ["PROMPT"]
