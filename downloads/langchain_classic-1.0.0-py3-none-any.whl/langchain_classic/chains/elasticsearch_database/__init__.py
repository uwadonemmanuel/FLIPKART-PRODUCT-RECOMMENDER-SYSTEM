from langchain_classic.chains.elasticsearch_database.base import (
    ElasticsearchDatabaseChain,
)

__all__ = ["ElasticsearchDatabaseChain"]
