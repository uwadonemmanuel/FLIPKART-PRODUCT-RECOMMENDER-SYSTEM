"""Keep here for backwards compatibility."""

from langchain_classic.chains.example_generator import generate_example

__all__ = ["generate_example"]
